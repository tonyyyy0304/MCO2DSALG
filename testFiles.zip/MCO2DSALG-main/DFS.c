#include "DFS.h"
#include "graph.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


/*
void create_Stack(struct Stack *stack, struct Graph *graph);
int is_empty(struct Stack *stack);
void push(struct Stack *stack);
int pop(struct Stack* stack);
*/


void create_Stack(struct Stack *stack, struct Graph *graph){

    stack->top = -1;
     for(int i = 0; i<graph->maxVertex; i++){
        stack->Stack[i] = 0;
     }        

}

int is_empty(struct Stack *stack){
    return stack->top = -1;
}

void push(struct Stack *stack, int vertex){
    if (stack->top < (stack->max - 1)){
        stack->Stack[++stack->top] = vertex;
    }
}
int pop(struct Stack* stack){
    if(is_empty(stack)){
        return -1;
    }
    return stack->Stack[stack->top--];
}

void depthFirstSearch(struct Stack *stack, struct Graph *graph, char* startVertex){
    int visited[100] = {0};
    int current;
    int vertexNum;
    // dapat int visited[graph->maxVertex] kaso hindi set ung maxVertex kaya di kaya, sinet ko muna ng 100 tulad kay jed
    vertexNum = getNameIndex(startVertex, graph);
    create_stack(stack, graph);
    push(stack, vertexNum);

    while (!is_empty(stack)){
        current = pop(stack);
        if(!visited[current]){
            printf("%s", graph->name[current]);
            visited[current] = 1;
            for(int i = 0; i < graph->maxVertex; i++){
                if(graph->matrix[current][i] == 1 && !visited[i]){
                    push(stack, i);
                }
            }
        }
    }

    free(stack->Stack);
    free(stack);
}